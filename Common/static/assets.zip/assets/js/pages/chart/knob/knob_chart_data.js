'use strict';
$(function () {
    $('.knob').knob({
        draw: function () {
        }
    });
});